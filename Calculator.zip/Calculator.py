import tkinter as tk

def evaluate_expression(expression):
    """Evaluate the expression and handle errors."""
    try:
        # Safely evaluate the expression
        result = eval(expression)
        return str(result)
    except Exception:
        return "Error"

def update_display(value):
    """Append value to the current text in the display."""
    current_text = display.get()
    display.delete(0, tk.END)
    display.insert(tk.END, current_text + value)

def clear_display():
    """Clear the display."""
    display.delete(0, tk.END)

def calculate():
    """Evaluate the current expression and show the result."""
    expression = display.get()
    result = evaluate_expression(expression)
    display.delete(0, tk.END)
    display.insert(tk.END, result)

# Create the main window
root = tk.Tk()
root.title("Simple Calculator")

# Create the display
display = tk.Entry(root, width=16, font=("Arial", 24), bd=10, borderwidth=4)
display.grid(row=0, column=0, columnspan=4)

# Define button text and their positions
buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
    ('C', 5, 0, 4)  # Note: This button spans 4 columns
]

# Create and place buttons
for button in buttons:
    text = button[0]
    row = button[1]
    col = button[2]
    colspan = button[3] if len(button) == 4 else 1
    
    if text == '=':
        button_widget = tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 18), command=calculate)
    elif text == 'C':
        button_widget = tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 18), command=clear_display)
    else:
        button_widget = tk.Button(root, text=text, padx=20, pady=20, font=("Arial", 18), command=lambda t=text: update_display(t))
    
    button_widget.grid(row=row, column=col, columnspan=colspan)

# Run the application
root.mainloop()
